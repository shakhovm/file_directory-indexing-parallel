The files in this etext are in Unicode.  You must have a
program available that can read Unicode to view them.

If you do not have such a program, please consider the
plain ASCII text files (ending in .txt), or the HTML
(Web) files, ending in .htm

Thanks for your interest in Project Gutenberg.  You can
find out about Project Gutenberg at the official Web site:
	http://www.gutenberg.net

